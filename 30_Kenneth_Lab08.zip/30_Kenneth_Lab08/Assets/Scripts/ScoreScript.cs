﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScoreScript : MonoBehaviour
{
    public Text Score;
    private int scoreInt;
    // Start is called before the first frame update
    void Start()
    {
        scoreInt = 0;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "Obstacle")
        {
            scoreInt++;
            Score.text = "Score: " + scoreInt;
        }
    }
}
