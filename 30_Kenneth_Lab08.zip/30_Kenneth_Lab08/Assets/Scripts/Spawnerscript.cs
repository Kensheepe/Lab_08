﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawnerscript : MonoBehaviour
{
    public GameObject SpawnObject;
    public GameObject brownCube;
    public GameObject greenCube;
    private int toSpawn;
    float PositionY;

    // Start is called before the first frame update
    void Start()
    {
        InvokeRepeating("SpawnObjects", 1, 1);
    }

    // Update is called once per frame
    void Update()
    {
       


    }

    void SpawnObjects()
    {
        PositionY = Random.Range(4, -4f);
        toSpawn = Mathf.FloorToInt(Random.Range(0f, 3f));
        
        this.transform.position = new Vector3(transform.position.x, PositionY, transform.position.z);
        if (toSpawn == 0)
        {
            Instantiate(SpawnObject, transform.position, transform.rotation);
        }
        else if (toSpawn == 1)
        {
            Instantiate(brownCube, transform.position, transform.rotation);
        }
        else if (toSpawn == 2)
        {
            Instantiate(greenCube, transform.position, transform.rotation);
        }
    }
}
